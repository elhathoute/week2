#include <stdio.h>
 /***** le programme principal (fonction main) *****/
main()
{
 float fexple (float, int, int) ; /* d�claration de fonction fexple */
 float x = 1.5 ; 
 float y, z ;
 int n = 3, p = 5, q = 10 ;
 /* appel de fexple avec les arguments x, n et p */
 y = fexple (x, n, p) ; 
 printf ("valeur de y : %e\n", y) ;
/* appel de fexple avec les arguments x+0.5, q et n-1 */ 
 z = fexple (x+0.5, q, n-1) ;
 printf ("valeur de z : %e\n", z) ;
}
 /*************** la fonction fexple ****************/
float fexple (float x, int b, int c)
{
 float val ; 
 val = x * x + b * x + c ;
 return val ;
}
