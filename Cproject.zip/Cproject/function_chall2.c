#include<stdio.h>
#include<stdlib.h>
 int a,b;
 
int main()
{
   int a,b;
    void echanger(int a,int b);
    int n=10, p=20 ;
  /* printf("entrer a et b \n");
   scanf("%d\%d",a,b);
    printf("la valeur initial de a=%d et b=%d \n",a,b);
 */
			echanger(n,p);
			
    return 0;
}
 void echanger(int a,int b){
   	int c;
   c=a;
   a=b;
   b=c;
 printf("les valeures apre change et n=%d et p=%d \n",a,b);
			}
