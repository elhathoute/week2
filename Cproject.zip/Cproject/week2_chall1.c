//Ecrire un algorithme qui demande un nombre � l�utilisateur,
// puis affiche sa table de multiplication de 1 � 10
#include<stdio.h>
int main(){
	int a,i,multip;
	
	printf("entrer un nbr entier:\n");
	scanf("%d",&a);
	for(i=1;i<=10;i++){
		multip=a*i;
			printf("la multipli par %d est : %d\n",i,multip);

		
	}

	
	
	
	
	
	return 0;
}
