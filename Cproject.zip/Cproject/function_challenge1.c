#include<stdio.h>
#include<stdlib.h>
int main()
{
   int a,b,some;
   printf("entrer a et b \n");
   scanf("%d\%d",&a,&b);
   int add(a,b){
   	
   	some=a+b;
   	return some;
			}
			printf("la somme est :%d\n",add(a,b));
    return 0;
}
