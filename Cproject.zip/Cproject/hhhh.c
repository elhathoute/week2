#include <stdio.h>
#include <stdlib.h>



int main(int argc, char *argv[]) {
	printf("hhhhhh");
	return 0;
}

