#include<stdio.h>
 int main(){
	/*	
char c;
int n;*/
//printf("entrer c \n");
//scanf("%c",&c);

////  do{ printf("la valeur de c est:%c\n ",c);} while ( c != 'x') ;
/*
do { }
 while ( printf ("donnez un char :\n"), scanf ("%c", &c),
 printf ("vous avez fourni %c \n", c),c!='x' ) ;
 */ 
	/*do { }
 while ( printf ("donnez un nb > 0 :"), scanf ("%d", &n),
 printf ("vous avez fourni %d", n), n <= 0 ) ;
*/
/*
 int n, som ;
 
 som = 0 ;
 while (som<100)
 { printf ("donnez un nombre : ") ;
 scanf ("%d", &n) ;
 som += n ;
 }
 printf ("somme obtenue : %d", som) ;
 
*/
int i;
// 1�re methode
/*
for ( i=1 ; i <= 5 ; printf("fin de tour\n"), i++ ) {
 printf("hello  %d \n",i);
 
	 }*/
 //////////2�me methode 
/* for ( i=1 ; i <= 5 ;  i++ ) {
 printf("hello  %d \n",i);
	printf("fin de tour\n");
	 }*/
	 /*
 for ( i=1, printf("on commence \n") ; printf("debut de tour\n"), i<=5 ; i++)
 {printf("hello  %d \n",i); }
*/
/*
printf ("on commence\n") ;
 for ( i=1 ; i<=5 ; i++ )
 { printf ("debut de tour\n") ;
  printf("hello  %d \n",i);
 }
*/
// le role de break
/*
for ( i=1 ; i<=10 ; i++ )
 { printf ("debut tour %d\n", i) ;
 printf ("bonjour\n") ;
 if ( i==3 ) break ;
 printf ("fin tour %d\n", i) ;
 }
 printf ("apres la boucle") ;*/
// le role de continue
/*
 for ( i=1 ; i<=5 ; i++ )
 { printf ("d�but tour %d\n", i) ; 
 if (i<4) continue ;// if i<4 repeter la meme chose mais if i>=4 continue a letape suivant
 printf ("bonjour\n") ;
 } */
// le role de goto

for ( i=1 ; i<=10 ; i++ )
 { printf ("d�but tour %d\n", i) ;
 printf ("bonjour\n") ;
 if ( i==3 ) goto sortie ;
 printf ("fin tour %d\n", i) ;
 }
 sortie : printf ("apr�s la boucle") ;





















































	return 0;
}
