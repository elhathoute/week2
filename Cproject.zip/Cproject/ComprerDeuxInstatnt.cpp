#include<stdio.h>
 int main(){
	int hh,mm,ss;
	int hh1,mm1,ss1;
		int k=1;  //
	printf("Entrer la 1ere instant sous format(HH:MM:SS);\n");
 scanf("%d%d%d",&hh,&mm,&ss);
 printf("---la 1ere instant est :%dH:%dM:%dS:\n",hh,mm,ss);
 printf(" /////////////////////////////////////////////////////////\n");
		printf("Entrer la 2ere instant sous format(HH:MM:SS);\n");
 scanf("%d%d%d",&hh1,&mm1,&ss1);
 printf("---la 2ere instant est :%dH:%dM:%dS:\n\n",hh1,mm1,ss1);

	if(hh1>hh)k=2;
    else	if((hh1==hh)&&(mm1>mm))k=2;
     else if((hh1==hh)&&(mm1=mm)&&(ss1>ss))k=2;
      else	if((hh1==hh)&&(mm1==mm)&&(ss1==ss)) k=0;
	switch(k){
		case 1:
				printf("la 1ere instant vient avant le deuxieme:\n");
				break;
				case 2:
				printf("la 2ere instant vient apre la premier:\n");
						break;
				case 0:
								printf("1ere instant egal a la deuxieme:\n");
										break;
	}
	return 0;
}
