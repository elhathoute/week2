#include<stdio.h>
int main(){
	float a,b,fa,fb,fm;
	 a=-15;
	 b=-10;
	float m;
	 

	 while((b-a)>(0.00001)){
	m=(a+b)/2;

	 	fa=(a*a*a)+(12*(a*a))+1;
	 	
	 	 	fb=(b*b*b)+(12*(b*b))+1;
	 	
	 	 	fm=(m*m*m)+(12*(m*m))+1;
	 	
	 	printf("m=%.5f\nfa=%.5f\nfb=%.5f\n fm=%.5f\n",m,fa,fb,fm);
	 	
	 	if((fa*fm)<0){
	 		b=m;
	 		
			}else {
			a=m;
			}
	 		}
	printf("la valeur est f(%f)=%f",m,fm);
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
