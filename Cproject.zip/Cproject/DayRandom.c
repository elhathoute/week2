#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(int argc, char *argv[]) {
  
    int Day;
    srand(time(0));  //INITIALISER LE TEMPS POUR A CHAQUE FOIS EN AFFICHE UN NBMR ALEATOIRE 
    Day=rand()%7;
    int rand2=rand();
      int rand3=rand();
  printf("%d\n",Day);

	switch(Day)
    {
       case 0: printf("lundi");
            break;
       case 1: printf("mardi");
            break;
       case 2: printf("mercredi");
            break;
       case 3: printf("jeudi");
            break;
       case 4: printf("vendredi");
            break;
       case 5: printf("samedi");
            break;
       case 6: printf("dimanche");
            break;
     
    }
  

	return 0;
}

