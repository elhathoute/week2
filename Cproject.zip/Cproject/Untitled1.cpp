#include<stdio.h>
 
double gd1, gd2;
 
void Echange (double, double);
 
int main()
   {
      printf("Entrez une valeur pour gd1 et gd2 : ");
      scanf("%lg %lg", &gd1, &gd2);
      Echange(gd1, gd2);
      printf("Les valeurs apres echange sont : gd1=%g et gd2=%g", gd1, gd2);
      return 0;
   }
 
void Echange (double gd1, double gd2)
   {
      double d;
      d=gd1;
      gd1=gd2;
      gd2=d;
  }
