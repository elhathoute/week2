#include<stdio.h>
#include<math.h>

int main(){
	
	float x1;
	float y1;
	float x2;
	float y2;
	float dist;
	printf("entrer la valeur de x1 \n");
	scanf("%f",&x1);
		printf("entrer la valeur de y1 \n");
	scanf("%f",&y1);
		printf("entrer la valeur de x2 \n");
	scanf("%f",&x2);
		printf("entrer la valeur de y2 \n");
	scanf("%f",&y2);
	
	dist=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
	
	printf("dist entre a et b est: %.2f",dist);
	return 0;
}