#include<stdio.h>

int main(){
	
	int num;
	int a,b,c,d ;
	printf("entrer un nombre entier a trois valeur	:\n");
	
	scanf("%d",&num);              // 123
	   a=num%10;                // 123%10=  3
	    b=num/10;             //123/10=12            (en prend la partie entier)
	     c=b%10;               //12%10=2              (le rest de la devision 12/10 egale a 2)
	       d=num/100;         //123/100=1        (la partie entiern 
	
	printf("l'inverse du nombre est: %d%d%d",a,c,d);
	
	
	return 0;
}