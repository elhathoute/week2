#include<stdio.h>

int main(){
    
   float TempFah;
   

  
   printf("Entrer TEMP EN FAH \n");
   scanf("%f",&TempFah);
         float TempCel=(TempFah-32)/1.8;
   
       	 printf("la temp en  Cel est %.2f ",TempCel);
       	 
	 
    return 0;
}
