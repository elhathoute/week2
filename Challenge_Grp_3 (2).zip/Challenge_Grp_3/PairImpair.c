#include<stdio.h>

int main(){
    
   int Nbr;
  int DivFor2;
   printf("Entrer un nombre entier\n");
   scanf("%d",&Nbr);
       
       
       if((Nbr%2)==0){
       	 printf("le nombre %d est pair\n",Nbr);
       	 
	   }
	   
	   else{
	   	 	 printf("le nombre %d est impair\n",Nbr);
	   }
    return 0;
}

