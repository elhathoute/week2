#include<stdio.h>

int main(){
	int nbr;  //  ------nbr decimal---------
	int inc=1; //  --------pour multip-------
	int octa=0;//  ------nbr octal---------
	int rest=0;//  ------rest de la div  de nbrDecimal par 8---------
    printf("entrer un nombre : \n");
	scanf("%d",&nbr);
  
     while(nbr!=0)  // OR USE ------while(num)---------
{
	rest=nbr%8;

	octa=octa+rest *inc;
	nbr=nbr/8;
	inc=inc*10;

}
	printf("la valeur octal est %d",octa);

	
	
	
	return 0;
}