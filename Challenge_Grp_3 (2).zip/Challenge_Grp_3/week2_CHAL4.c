		
		
		
		
		#include<stdio.h>
		int main(){
			int nbr;
			int i=1;
			int somme=0;
			int max=1;	
		
				
		printf("entrer un entier \n");
		          	while(nbr!=0){
		          		
		          	do{
		          scanf("%d",&nbr);
		           if(nbr>100) printf("entrer un nbr >0 et <100 \n");
		          	
					  }  while(nbr>100);
		          		somme=somme+nbr;
		          		if(nbr>max)  max=nbr;		
		           }
				  
					printf("la somme est %d \n",somme);
		          	printf("le max est %d \n",max);
					  	return 0;
		
}