#include<stdio.h>
#include<math.h>
int main(){
	
	int a,b,c,delta,sqrtD;
	float x1,x2;
	printf("entrer la valeur de a :\nentrer la valeur de b :\nentrer la valeur de c :\n");
	scanf("%d%d%d",&a,&b,&c);

	delta=(pow(b,2)-(4*a*c));
	
     sqrtD=sqrt(delta);
	
	if(delta>0){
	
		printf("les deux solution sont:X1=%.2f  X2=%.2f \n",x1,x2);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}