#include<math.h>
int main(){
	
	float a,b,c,delta,sqrtD;
	float x1,x2;
	printf("entrer la valeur de a :\nentrer la valeur de b :\nentrer la valeur de c :\n");
	scanf("%d%d%d",&a,&b,&c);

	delta=(pow(b,2)-(4*a*c));
	
     sqrtD=sqrt(delta);
	
	if(delta>0){
		x1=(-b)/(2*a);
	
		printf("les  solution sont:X1=%.2f  X2=%.2f \n",x1,x2);
	}	
	else if(delta==0){
		
		x1=(-b)/(2*a);
	
		printf("la  seul  solution est:X1=%.2f   \n",x1);
	}
		else {
		
		//printf("les  deux  solution en C  est: \n X1=%.2f+i*%.2f \n X2=%.2f-i*%.2f \n",((-b)/2*a),sqrt(-delta)/(2*a),((-b)/2*a),sqrt(-delta)/(2*a));
	}
	
	return 0;
	}	