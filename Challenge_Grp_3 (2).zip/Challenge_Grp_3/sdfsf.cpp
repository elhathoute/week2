

//Écrire le programme pour avoir un pyramide d'étoile, le nombre des lignes à composer est demandé à l’utilisateur.
//(chaque ligne doit avoir un nombre premier d'étoiles.

#include<stdio.h>
int main(){
	int nbr,i,j,k;
	

					printf("entrer un nbr impaire  :\n");
						scanf("%d",&nbr);

						
							int	x=nbr/2;
						   int y=x/2;
				
        
if(-5){

				
							for(i=0;i<(x+1);i++){ 
						  		   
									for(j=0;j<=(x-i);j++){
						printf(" ");
							}
								for(k=1;k<=(2*i+1);k++)  {
									printf("*");
							}
					printf("\n");
						}
					
					}
			
	
		
return 0;
}
