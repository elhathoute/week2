#include<stdio.h>

int main()

{

int a = 10;

 //float a = 1.1; double declaration non autoriser
a=1.1;
printf("%d", a);

return 0;

}