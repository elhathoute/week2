#define N 5

#include<stdio.h>
                                 // indice de tableaux :|0|1|2|3|4|   
int tab[5] = {1, 2, 6, 0, 7};  //les valeur du tableaux:|1|2|6|0|7|
main()
{
  int i;
  int *p;  //declaration des pointeurs
  //Tout tableau en C est en fait un pointeur constant. Dans la déclaration est int tab[10];

  p = tab;   //tab est un pointeur constant (non modifiable) dont la valeur est l'adresse du premier élément du tableau. 
  //Autrement dit, tab a pour valeur &tab[0]. 
 // On peut donc utiliser un pointeur initialisé à tab pour parcourir les éléments du tableau.                      
  
  printf("-----------indice de tableaux :|0|1|2|3|4|--------------  \n\n\n");
   printf("-------les valeur du tableaux:|1|2|6|0|7| --------\n\n\n");
   
    printf(" la valeur du *(p+2)=tab[2]=%d \n",*(p+2));
    
   printf("la valeur de *(p)+2=*p+2=tab[0]+2=%d \n",*p+2); // different de *(p+2)  par ce que *(p)=tab[0]=1  
   
   printf("adress du tab %d  adress du p %d ",tab,p); // les adress du pointeur et tableaux sont egaux  (p = tab; )
  
   return 0;
}
