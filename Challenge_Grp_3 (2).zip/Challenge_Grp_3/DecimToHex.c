#include<stdio.h>

int main(){
	
	int nbr; 
	
	int index=0;  // indice de table hex

    char hex[15];
    int a;  // indice pour boucler  la table A l' inverse
   //  int nbr09[10]={'0','1','2','3','4','5','6','7','8','9'};  // tableaux entre 0 ET 9
    printf("entrer un nombre en diccimal: \n");
	scanf("%d",&nbr);
	
	while(nbr%16>0){
		switch(nbr%16){
				case 0:
		  		hex[index]='0'; break;
		  			case 1:
		  		hex[index]='1'; break;
		  			case 2:
		  		hex[index]='2'; break;
		  			case 3:
		  		hex[index]='3'; break;
		  			case 4:
		  		hex[index]='4'; break;
		  			case 5:
		  		hex[index]='5'; break;
		  			case 6:
		  		hex[index]='6'; break;
		  			case 7:
		  		hex[index]='7'; break;
				case 8:
		  		hex[index]='8'; break;
		  		case 9:
		  		hex[index]='9'; break;
		  //////////////////////////////////////////////////////
				case 10:
		  		hex[index]='A'; break;
				case 11:
		  		hex[index]='B'; break;
				case 12:
		  		hex[index]='C'; break;
		  		case 13:
		  		hex[index]='D'; break;
		  		case 14:
		  		hex[index]='E'; break;
		  		case 15:
		  		hex[index]='F'; break;
		  	
				}
				nbr=nbr/16;
				index++;
	}  
			
	printf("la valeur en hexaDeci est: \n");
	 				                  
			for(a=index;a>=0;a--)	{
				printf("%c",hex[a]);
			}	   	
	return 0;
}