#include <stdio.h>
 
int main()
{
	
	printf("kj,dkj");
  
  
    return 0;
}