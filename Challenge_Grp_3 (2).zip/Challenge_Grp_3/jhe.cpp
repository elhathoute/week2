//Écrire le programme pour avoir un pyramide d'étoile, le nombre des lignes à composer est demandé à l’utilisateur.
//(chaque ligne doit avoir un nombre premier d'étoiles.

#include<stdio.h>
int main(){
	int nbr,i,j,k;
	

					if(0) printf("Hi");
			
	
		
return 0;
}
