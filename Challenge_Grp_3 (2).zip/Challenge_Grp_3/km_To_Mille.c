#include<stdio.h>

int main(){
    
   float metre;
    float mille;


  // transfert metre to  mille
   printf("Entrer dist en metre  \n");
   scanf("%f",&metre);
         mille=(metre*1000)/1.609;
   
       	 printf("la dist  en  mille est %.2f \n",mille);
       	 
	 // transfert  mille  to metre
	 
	  printf("Entrer dist en mille \n");
   scanf("%f",&mille);
         metre=(mille*1.609)/1000;
   
       	 printf("la dist  en  METRE est %.2f ",metre);
    return 0;
}
