#include<stdio.h>

int main(){
	int choix;
	int nbrA;
   long nbrMo,
      nbrJou,
      nbrH,
      nbrMin,
      nbrSec;
printf("----------------------Menu-------------------------:\n");

   
   	printf("\n Entrer nbr of annee!:\n");
     scanf("%d",&nbrA);
     
      printf("vous etre  entrer %d Annee:\n",nbrA);
       printf("1-MOIS:\n");
   	printf("2-JOURS:\n");
   	printf("3-HEURES:\n");
   	printf("4-MINUTES:\n");
   	printf("5-SECOND:\n");
   	printf("--------------------choisi votre  option:-------------------------:\n");
   	scanf("%d",&choix);
      nbrMo=nbrA*12;
      nbrJou=nbrMo*30;
      nbrH=nbrJou*24;
      nbrMin=nbrH*60;
      nbrSec=nbrMin*60;
   	  switch (choix) 
    {
    case 1:
        printf("Vous avez choisis les MOIS : %ld MOIS \n ", nbrMo);
        break;
    case 2:
        printf("ous avez choisis les Jours: %ld JOURS \n",nbrJou);
    
    case 3:
        printf("ous avez choisis les Heures %ld heures \n", nbrH);
        break;
    case 4:
        printf("ous avez choisis les minutes %ld minutes \n", nbrMin);
        break;
           case 5:
         printf("ous avez choisis les second %ld secondes \n ",nbrSec);
        break;
    default:
        printf("Choisir le bon option!");
        break;
    }
     
	return 0;
}